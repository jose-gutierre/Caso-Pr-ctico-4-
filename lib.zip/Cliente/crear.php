<?php
require_once 'lib/nusoap.php';
$cliente = new nusoap_client("http://localhost/practica/index.php?wsdl", true);

$marca =  $_POST['marca'];
$modelo =  $_POST['modelo'];
$almacenamiento =  $_POST['almacenamiento'] ;
$ram =  $_POST['ram'];

    $param = array(array('marca' => $marca, 'modelo' => $modelo, 'almacenamiento' => $almacenamiento, 'ram' => $ram));
    $respuesta = $cliente->call("constructor.crear", $param);

    include_once 'home.php';


?>