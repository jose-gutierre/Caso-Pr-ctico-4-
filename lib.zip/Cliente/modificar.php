<?php
require_once 'lib/nusoap.php';
$cliente = new nusoap_client("http://localhost/practica/index.php?wsdl", true);

$id= $_POST['id'];
$marca =  $_POST['marca'];
$modelo =  $_POST['modelo'];
$almacenamiento =  $_POST['almacenamiento'] ;
$ram =  $_POST['ram'];

    $param = array(array('id' => $id,'marca' => $marca, 'modelo' => $modelo, 'almacenamiento' => $almacenamiento, 'ram' => $ram));
    $respuesta = $cliente->call("constructor.actualizar", $param);

    include_once 'home.php';


?>