<?php
require_once 'lib/nusoap.php';

$cliente = new nusoap_client("http://localhost/practica/index.php?wsdl", true);
$id= $_POST['id'];

    $param = array('id' => $id);
    $respuesta = $cliente->call("constructor.eliminar", $param);
    print_r($respuesta);
    require_once 'home.php';


?>