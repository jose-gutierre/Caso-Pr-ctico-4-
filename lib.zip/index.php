<?php
require_once 'conexion.class.php';
require_once "lib/nusoap.php";
$namespace = "http://localhost/practica/index.php";

$server = new soap_server();
$server->configureWSDL( "CRUDService" );
$server->soap_defencoding = 'utf-8';
$server->wsdl->schemaTargetNamespace = $namespace;

$server->wsdl->addComplexType(
    'createComplex',
    'complexType',
    'struct',
    'all', //Todo el bloque genera la estrutura xml donde estaran los campos para insertar los datos.
    '',
    array(
        'marca'          => array( 'name' => 'marca', 'type' => 'xsd:string' ),
        'modelo'         => array( 'name' => 'modelo', 'type' => 'xsd:string' ),
        'almacenamiento' => array( 'name' => 'almacenamiento', 'type' => 'xsd:string' ),
        'ram'            => array( 'name' => 'ram', 'type' => 'xsd:string' ),
    ) );

$server->wsdl->addComplexType(
    'updateComplex',
    'complexType',
    'struct',
    'all', //Todo el bloque genera la estrutura xml donde estaran los campos para insertar los datos para actualizar.
    '',
    array(
		'id'             => array( 'name' => 'id', 'type' => 'xsd:string' ),
        'marca'          => array( 'name' => 'marca', 'type' => 'xsd:string' ),
        'modelo'         => array( 'name' => 'modelo', 'type' => 'xsd:string' ),
        'almacenamiento' => array( 'name' => 'almacenamiento', 'type' => 'xsd:string' ),
        'ram'            => array( 'name' => 'ram', 'type' => 'xsd:string' ),
    ) );

	

$server->register( "constructor.crear",
    array( 'datos' => 'tns:createComplex' ),
    array( 'return' => 'xsd:string' ),
    $namespace,
    true,
    'rpc',
    'encoded',
    'Inserta nuevo registro a la base de datos'
);


$server->register( "constructor.actualizar",
    array( 'datos' => 'tns:updateComplex' ),
    array( 'return' => 'xsd:string' ),
    $namespace,
    true,
    'rpc',
    'encoded',
    'Actualiza registro a la base de datos'
);


$server->register("constructor.eliminar",
array('id' => 'xsd:int'),
array('return'=>'xsd:string'),
$namespace,
false,
'rpc',
'encoded',
'Elimina un dato por id de la BD');



$server->register("constructor.listar",
						array(),
						array('return'=>'xsd:string'),
						$namespace,
						false,
						'rpc',
						'encoded',
						'Devuelve todos los datos de la BD');











$POST_DATA = isset( $GLOBALS['HTTP_RAW_POST_DATA'] ) ? $GLOBALS['HTTP_RAW_POST_DATA'] : '';
$server->service( file_get_contents( "php://input" ) );
exit();
