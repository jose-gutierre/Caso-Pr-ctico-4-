<?php
class constructor
{

    private $mysqli;
    public $errorConexion;

    public function __construct()
    {
       // $this->mysqli = new mysqli( 'bvhhbxpj1jm5fzyoxefz-mysql.services.clever-cloud.com', 'ucicyf0b2qhieacu', 'aS9Eq2d5yzTwkNDRqwnK', 'bvhhbxpj1jm5fzyoxefz' );
        $this->mysqli = new mysqli( 'localhost', 'root', '', 'celulares' ); 
        if ( mysqli_connect_error() ) {
            $this->errorConexion = true;
        }
    }

    public function __destruct()
    {
        $this->mysqli->close();
    }

    public function crear( $datos )
    {
        if ( !$this->errorConexion ) {

            $mysqli = $this->mysqli;
            $marca = $mysqli->real_escape_string( trim( $datos['marca'] ) );
            $modelo = $mysqli->real_escape_string( trim( $datos['modelo'] ) );
            $almacenamiento = $mysqli->real_escape_string( trim( $datos['almacenamiento'] ) );
            $ram = $mysqli->real_escape_string( trim( $datos['ram'] ) );

            $datos = $mysqli->prepare( 'INSERT INTO especificaciones (marca,modelo,almacenamiento,ram) VALUES (?,?,?,?)' );
            $datos->bind_param( 'ssss', $marca, $modelo, $almacenamiento, $ram );
            $datos->execute();
            return 'Registro exitoso';
        } else {
            return 'Error estableciendo la conexión con la base de datos';
        }
    }

    public function actualizar( $datos )
    {
        if ( !$this->errorConexion ) {
            $mysqli = $this->mysqli;

            $id = $mysqli->real_escape_string( trim( $datos['id'] ) );
            $marca = $mysqli->real_escape_string( trim( $datos['marca'] ) );
            $modelo = $mysqli->real_escape_string( trim( $datos['modelo'] ) );
            $almacenamiento = $mysqli->real_escape_string( trim( $datos['almacenamiento'] ) );
            $ram = $mysqli->real_escape_string( trim( $datos['ram'] ) );

            $update = $mysqli->prepare( 'UPDATE especificaciones SET marca = ?,modelo= ?,almacenamiento= ?,ram=? WHERE id = ?' );
            $update->bind_param( 'ssssi', $marca, $modelo, $almacenamiento, $ram, $id );
            $update->execute();
            return 'Actualización exitosa';
        } else {
            return 'Error estableciendo la conexión con la base de datos';
        }

    }

    public function eliminar( $idregistro )
    {
        if ( !$this->errorConexion ) {
            $mysqli = $this->mysqli;
            $id = $mysqli->real_escape_string( trim( $idregistro ) );
            $delete = $mysqli->prepare( 'DELETE FROM especificaciones WHERE id = ?' );
            $delete->bind_param( 'i', $id );
            $delete->execute();
            return 'Se elimino satisfactoriamente';
        } else {
            return 'Error estableciendo la conexión con la base de datos';
        }

    }

    public function listar(){
        if(!$this->errorConexion){
            $tabla = $this->mysqli -> query('SELECT id,marca,modelo,almacenamiento,ram FROM especificaciones');
            
            $html = '<table class="table table-hover">
                        <tbody>';
            while ($lista = $tabla -> fetch_assoc()) {
                $html .= '<tr>
                            <td="Id">'.$lista['id'].'</td>
                            <td="Marca>'.$lista['marca'].'</td>
                            <td="Modelo>'.$lista['modelo'].'</td>
                            <td="Almacenamiento">'.$lista['almacenamiento'].'</td>
                            <td="Memoria RAM">'.$lista['ram'].'</td>
                        </tr>';
                }
                $html .= '<tr>
                        
                    </tr>
                    </tbody>
                    </table>';
            return $html;
        }
        else
            return '<p class="error">Error estableciendo la conexión con la base de datos</p>';
    }



  

    

}
